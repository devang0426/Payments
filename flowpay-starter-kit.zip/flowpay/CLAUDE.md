# FlowPay — Project guide for Claude Code

FlowPay is an Android demo app: the user says "Mummy ko 500 bhejo" (send 500 to Mom), the app
understands it, shows a confirmation, and opens PhonePe directly via a UPI intent, where the user
enters their own PIN.

Full design: `docs/ARCHITECTURE.md`. Current progress: `docs/PROGRESS.md`.
Read both at the start of every session.

## Hard rules (never break these)

1. **The AI only understands.** The server's AI only extracts `{ name, amountText }`. The amount is
   always converted to integer paise by the code in `apps/server/src/amount.ts`. A number produced
   by the AI never becomes a payment amount directly.
2. **Money = integer paise.** Never use floats for money anywhere. ₹500 = `50000`.
   Convert to rupees only for display.
3. **Privacy:** contacts, phone numbers, UPI IDs (VPAs) and payment history never go to the server
   or the AI. The server only receives the spoken/typed text.
4. **Secrets:** `OPENROUTER_API_KEY` lives only on the server. No keys in mobile code.
   `EXPO_PUBLIC_*` variables are bundled into the app, so they hold only the server URL.
5. **Gitignored files:** `.env`, `apps/server/.env`, `apps/mobile/.env`, `apps/mobile/payees.local.json`.
   Never commit, print, log or paste their contents. Use `payees.example.json` (fake data) for
   examples.
6. **Guardrails (on the phone):** ₹3,000 per payment (`300000` paise), ₹5,000 per day (`500000` paise,
   IST calendar day). The payee must exist in the saved payees. Any rule failure = red card + reason,
   and PhonePe does not open. Payments with status "unknown" also count toward the daily limit
   (err on the safe side).
7. **The app never sees the UPI PIN.** Payment happens only via UPI intent, inside PhonePe.
8. **Confirmation is mandatory:** the intent is never launched without the confirm card plus the
   user's "Yes" (tap or voice). The confirm button disables after one tap (no double payments).
9. If the server or internet fails, the payment never proceeds. Show "Couldn't understand that,
   please try again."

## Repo layout

```
flowpay/
  CLAUDE.md
  docs/                     ARCHITECTURE, PROMPTS, PROGRESS, TEST-CHECKLIST
  apps/
    mobile/                 Expo (React Native) + TypeScript + Expo Router + NativeWind
      app/                  screens: index (Home), confirm, receipt, settings
      lib/
        contacts.ts         name → contact → phone number (expo-contacts)
        match.ts            name normalization + matching (pure, tested)
        payees.ts           phone → UPI ID (SecureStore, filled from seed)
        rules.ts            limits (pure, tested)
        upi.ts              build UPI URI (pure, tested) + open PhonePe
        history.ts          local payments in AsyncStorage
        api.ts              server /parse call + Zod validation
        strings.ts          all user-facing text in one place
      payees.local.json     real UPI IDs (gitignored)
      payees.example.json   fake data (committed)
    server/
      src/index.ts          Express app, POST /parse
      src/amount.ts         spoken amount → paise (pure, tested)
      src/llm.ts            OpenRouter call
```

`apps/mobile` and `apps/server` are **two separate npm projects**. Do not set up npm workspaces at
the root (a monorepo setup with Expo's Metro bundler is more hassle than a demo needs).

## Commands

```
# server
cd apps/server && npm run dev        # local server, port from .env (default 3000)
cd apps/server && npm test           # Vitest

# mobile
cd apps/mobile && npx expo start     # scan the QR code with Expo Go
cd apps/mobile && npm test           # Jest
```

## Code conventions

- TypeScript strict mode in both projects.
- Keep pure logic (amount, match, rules, UPI URI) free of React/Expo imports so tests run without
  a phone.
- Validate both the server response and the seed file with Zod. Validation failure = user-friendly
  error.
- Use the `Asia/Kolkata` timezone for dates and limits.
- Logging: never log the user's text in production. Log error types, not content.
- All UI text is English and lives in `lib/strings.ts`.
- Voice input will be in Hinglish/Hindi (e.g. "Mummy ko paanch sau bhejo"), so parsing and name
  matching must handle Hindi number words and relationship names.

## How to work

- One session = one milestone (see `docs/PROMPTS.md`). Don't build anything outside its scope.
- For money/safety files (`amount.ts`, `rules.ts`, `upi.ts`, `match.ts`): **tests first, then
  implementation**. Show the tests to the user before writing the code.
- Small diffs. Explain why before installing any new package.
- For anything that can only be tested on the phone (contacts, PhonePe, mic, TTS), give the user
  exact steps for what to check.
- At the end of a milestone, update `docs/PROGRESS.md`: what was built, what's left, known issues.
- If something doesn't work after 2-3 attempts, stop, explain the cause, and suggest a different
  approach.
