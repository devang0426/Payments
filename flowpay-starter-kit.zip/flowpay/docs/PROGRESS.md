# FlowPay — Progress log

Claude Code updates this file after every milestone. Read it first in every new session.

## Status

| Milestone | Status | Notes |
|---|---|---|
| M0 Scaffold | ⬜ | |
| M1 Amount parser | ⬜ | |
| M2 /parse + OpenRouter | ⬜ | |
| M3 Phone pure logic | ⬜ | |
| M4 Screens | ⬜ | |
| M5 Real PhonePe (₹1) | ⬜ | |
| M6 Wire together + voice | ⬜ | |
| M7 History + polish | ⬜ | |
| M8a Vercel | ⬜ | |
| M8b In-app mic | ⬜ | |
| M8c Release APK | ⬜ | |

⬜ not started · 🟡 in progress · ✅ done · 🔴 blocked

## Known issues

_(none yet)_

## Decisions

- mobile and server are separate npm projects (no workspaces).
- Amounts are always parsed by code, never by the AI.

## Log

<!-- Newest entry on top. Format:
### YYYY-MM-DD — Mx
- Built:
- How it was tested:
- Next step:
-->
