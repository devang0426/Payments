# FlowPay — Milestone prompts

Paste each prompt in plan mode. One session = one milestone. Commit and `/clear` after each one.

The order is deliberate: the riskiest parts (parsing money, real PhonePe) come early, and wiring
in the AI comes near the end.

---

## M0 — Scaffold

```
Read docs/ARCHITECTURE.md and CLAUDE.md. Do M0: the project skeleton.

1. apps/server: Node + Express + TypeScript (strict). `npm run dev` with tsx, `npm test` with Vitest.
   GET /health → { ok: true }. Read PORT via dotenv (default 3000). Listen on 0.0.0.0 so the phone
   can reach it over the same Wi-Fi.
2. apps/mobile: Expo (latest SDK) + TypeScript + Expo Router + NativeWind. One Home screen that
   shows "FlowPay" and calls /health at EXPO_PUBLIC_API_URL, displaying the status.
   Set up Jest (jest-expo preset). Create lib/strings.ts for all UI text.
3. Two separate npm projects, no root workspaces.
4. The .env.example files already exist; don't change them. Check .gitignore.
5. Update docs/PROGRESS.md.

Tell me exactly what to check on the phone.
```

**Done**
- [ ] `cd apps/server && npm run dev` runs, and `http://localhost:3000/health` in a browser → `{"ok":true}`
- [ ] `cd apps/mobile && npx expo start`, scan the QR with Expo Go, the app opens
- [ ] The app shows server status "ok" (laptop and phone on the same Wi-Fi, laptop IP in `.env`)
- [ ] `npm test` runs in both projects (a dummy test is fine for now)

Tip: the Windows firewall can block the phone from reaching the laptop. If the status fails,
check that first.

---

## M1 — Amount parser (the most important piece)

```
Do M1: apps/server/src/amount.ts. Function: parseAmount(text: string) →
{ ok: true, paise: number } | { ok: false, reason: string }.
Paise are always integers. Never calculate money with floats (handle fractions in paise).

FIRST write only the Vitest tests and show them to me. At minimum these cases
(input is Hinglish/Hindi as spoken by Indian users):
- Digits: "500" → 50000, "₹500", "Rs 500", "rs.500", "500 rupaye", "500 rs", "1,500" → 150000,
  "250.50" → 25050
- Hindi number words: ek (1), do (2), teen (3), chaar (4), paanch (5), chhe (6), saat (7),
  aath (8), nau (9), das (10), bees (20), pachaas (50), sau (100), hazaar/hajar/hazar (1000)
- Combinations: "paanch sau" → 50000, "do hazaar" → 200000, "do hazaar paanch sau" → 250000,
  "ek sau bees" → 12000
- Fractions: "dedh sau" (1.5×100) → 15000, "dhai sau" (2.5×100) → 25000,
  "saadhe teen sau" (3.5×100) → 35000, "sawa sau" (1.25×100) → 12500,
  "paune do sau" (1.75×100) → 17500, "dedh hazaar" → 150000
- Mixed: "5 sau" → 50000, "2 hazaar" → 200000, "1.5k" → 150000, "2k" → 200000
- Spelling variants: "paach", "panch", "dhaai", "sade", "saade"
- Failure cases (ok:false): "", "kuch paise" (some money), "bahut saare" (a lot), "0", "-500",
  text with more than one amount like "500 ya 600" (500 or 600)

Don't check limits here (that's rules.ts on the phone); just parse correctly.
Once I approve the tests, implement until all are green. Update PROGRESS.md.
```

**Done**
- [ ] All tests green
- [ ] You read the test file yourself and had 3-4 of your own cases added (the way your family
  actually talks)

---

## M2 — /parse endpoint + OpenRouter

```
Do M2: POST /parse in apps/server.

Request: { text: string } (Zod validated, max 300 chars).
Flow:
1. src/llm.ts: OpenRouter chat completions call (OPENROUTER_API_KEY, OPENROUTER_MODEL from env).
   System prompt: from a Hinglish/Hindi/English payment command, extract only { name, amountText }
   as JSON. amountText = the part of the text that states the amount, exactly as spoken (don't
   convert it). Use null if the name or amount isn't present. Use JSON mode if the model
   supports it. 10 second timeout.
2. Validate the AI output with Zod.
3. Convert amountText to paise with parseAmount(). Never use a number from the AI directly.
4. Response:
   { ok: true, name: string, amountPaise: number }
   | { ok: false, error: "NO_NAME" | "NO_AMOUNT" | "AI_FAILED" | "BAD_INPUT" }

Also:
- A simple rate limit (express-rate-limit, e.g. 30 req/min per IP) so API key costs can't run away.
- Don't log the user's text, only the error type.
- Tests: mock llm.ts and cover every /parse branch (with supertest).
- Put a curl example in docs/PROGRESS.md.
```

**Done**
- [ ] You added the key and model to `apps/server/.env` yourself
- [ ] `curl` with "Mummy ko paanch sau bhejo" → `{"ok":true,"name":"Mummy","amountPaise":50000}`
- [ ] "Papa ko dhai sau" and "Rahul ko 1.5k" also correct
- [ ] "kya haal hai" (how are you) → `ok:false`
- [ ] Mock tests green

---

## M3 — Phone-side pure logic (no UI)

```
Do M3: pure logic + Jest tests in apps/mobile/lib. No UI yet.

1. lib/match.ts: normalizeName() (lowercase, strip Hindi honorific suffixes like "ji", "jee",
   "bhaiya", "didi", extra spaces, common spellings: mummy/mumma/mumy/mom/maa,
   papa/pappa/dad).
   matchContacts(spokenName, contacts[]) → { kind: "one", contact } | { kind: "many", contacts }
   | { kind: "none" }. Also consider payee aliases.
2. lib/rules.ts: checkPayment({ amountPaise, payee, todayHistory }) →
   { ok: true } | { ok: false, reason: "OVER_PER_PAYMENT" | "OVER_DAILY" | "NO_PAYEE" | "ZERO" }.
   Limits: 300000 / 500000 paise. Day = Asia/Kolkata calendar day. History entries with status
   "success" and "unknown" both count; "failed" doesn't.
3. lib/upi.ts (pure part only): buildUpiUri({ vpa, name, amountPaise, note, txnRef }) →
   upi://pay?pa=..&pn=..&am=500.00&cu=INR&tn=..&tr=.. (correct URL encoding, am always 2 decimals).
   parseUpiResponse(responseString) → "success" | "failed" | "unknown"
   (format: "txnId=..&responseCode=..&Status=SUCCESS&txnRef=.."; case-insensitive,
   missing = unknown).
4. lib/payees.ts: Zod schema matching the format of payees.example.json. Load the seed into
   SecureStore on first run. The build must NOT break if payees.local.json is missing: add a
   small script (scripts/ensure-payees.js, run on npm postinstall/prestart) that copies the
   example file if the local one doesn't exist.
5. Jest tests for every edge case: two "Mummy" contacts, name not found, exactly ₹3,000
   (allowed), ₹3,000.01 (blocked), close to the daily limit, 11:59 PM vs 12:01 AM IST,
   UPI response variants.

Show me the tests first, then implement.
```

**Done**
- [ ] All Jest tests green
- [ ] `npx expo start` still works after deleting `payees.local.json`

Note: `payees.local.json` gets bundled inside the APK. Never send the demo APK to anyone else.

---

## M4 — Screens (no AI yet)

```
Do M4: the UI flow with NativeWind, without the server.

Screens (Expo Router):
- Home (app/index.tsx): large text input "Who do you want to pay, and how much?" (the user can
  dictate with the keyboard mic), "Next" button. For now use a FAKE parser (lib/fakeParse.ts:
  the pattern "<name> ko <number>") so the flow can be tested. Last 5 payments below.
- Confirm (app/confirm.tsx): payee name, last 4 digits of their phone, masked UPI ID, large amount
  (₹500), "Yes, send" and "No" buttons. If a rule fails, show a red card with the reason, and
  don't show the "Yes" button at all. "Yes" disables after one tap.
- Disambiguation: if matchContacts returns "many", show a "Which Mummy?" list.
- Receipt (app/receipt.tsx): status (Done / Failed / Unknown), amount, name, time, txnRef.
- Settings (app/settings.tsx): payee list with add/edit/delete (SecureStore), amount sent today.

Request contacts permission with expo-contacts; if denied, explain why it's needed.
For now, "Yes" must NOT open PhonePe; go straight to Receipt with a fake "success".
Simple, clean UI with big buttons (parents should be able to use it too).
All text goes through lib/strings.ts.
```

**Done**
- [ ] Type "Mummy ko 500" and reach Confirm with the right name and amount
- [ ] "Mummy ko 4000" → red card, no Yes button
- [ ] Two contacts with the same name → a list appears
- [ ] Add a payee in Settings, close and reopen the app, the payee is still there

---

## M5 — Real PhonePe (₹1 to yourself)

```
Do M5: launchPhonePe() in lib/upi.ts.

- expo-intent-launcher startActivityAsync, action "android.intent.action.VIEW",
  data = buildUpiUri(...), packageName "com.phonepe.app".
- Extract the "response" string from the result extras and pass it to parseUpiResponse().
  Handle resultCode and extras safely (either can be undefined).
- PhonePe not installed / launch fails → user-friendly error, no crash.
- Unique txnRef for every payment (timestamp + random).
- No result or "unknown" → on Receipt, ask "Did the payment go through?" [Yes] [No] and save the
  answer to history.
- "Yes" on the Confirm screen now calls the real launchPhonePe().
- A DEBUG section in Settings (only in __DEV__) showing the last intent's raw resultCode + extras,
  so we can see what PhonePe actually returns.
```

**Done (you, on the phone)**
- [ ] Add **your own** UPI ID as a payee in Settings
- [ ] "Me ko 1" → Confirm → Yes → PhonePe opens with **name and ₹1.00 prefilled**
- [ ] Check the payee's real name shown in PhonePe, enter your PIN
- [ ] Back in the app, Receipt shows the correct status
- [ ] Press back on the PIN screen → "Failed" or the "Did the payment go through?" question

**This is the biggest risk.** Some UPI apps block, limit or warn on intents from other apps that
pay personal (non-merchant) UPI IDs. That's why M5 comes early. If PhonePe blocks the intent, have
Claude build a fallback: "Copy UPI ID + open PhonePe", or show a UPI QR code on the Confirm screen.
The demo story still works.

---

## M6 — Wire everything together (server + voice)

```
Do M6: remove the fake parser and connect the real flow.

1. lib/api.ts: POST {EXPO_PUBLIC_API_URL}/parse, 12 sec timeout, validate the response with Zod.
   Messages for every failure:
   NO_AMOUNT → "How much do you want to send?", NO_NAME → "Who do you want to pay?",
   network/AI_FAILED → "Couldn't understand that, please try again."
2. Home → api.parse → matchContacts → payee lookup → rules → Confirm.
   Name found but no UPI ID → "No UPI ID saved for Mummy" + a button to Settings.
3. expo-speech: when the Confirm screen opens, say "Send 500 rupees to Mummy?".
   Speak the reason on a red card too.
4. Loading state while the server is thinking.
```

**Done**
- [ ] Say "Mummy ko paanch sau bhejo" with the Gboard mic → Confirm card + voice
- [ ] Stop the laptop server → "Couldn't understand that" and nothing proceeds
- [ ] "Mummy ko bhejo" (no amount) → "How much do you want to send?"

---

## M7 — History + "same as last time" + polish

```
Do M7:
1. lib/history.ts: payments in AsyncStorage { id, payeePhone, payeeName, amountPaise, status,
   txnRef, createdAt }. Validate with Zod on read (no crash on corrupt data).
2. "Same as last time" (spoken as "pichhli baar jitna" / "utna hi" / "same as last time"): the
   server's AI returns a marker like amountText "LAST" (update the system prompt + test), and the
   phone uses the amount of that payee's last successful payment. No previous payment →
   "No previous payment found. How much do you want to send?"
3. History list on Home, "Share" on Receipt (text receipt via React Native's Share API).
4. Go through every case in the "If something goes wrong" table in docs/ARCHITECTURE.md and build
   whatever is missing.
5. Tests for any new pure logic.
```

**Done**
- [ ] Send ₹1 to Mummy, then "Mummy ko pichhli baar jitna" → Confirm for ₹1
- [ ] Ran every case from the "If something goes wrong" table once on the phone

---

## M8 — Demo prep: Vercel + APK + in-app mic

Do this milestone as three short sessions.

**M8a — Server on Vercel**
```
M8a: make apps/server deployable on Vercel (check Vercel's current Express docs for the setup).
I'll add the env variables in the Vercel dashboard myself; just tell me which ones.
Local `npm run dev` must keep working.
```
- [ ] `https://<your-project>.vercel.app/health` → ok
- [ ] curl /parse works against the Vercel URL

**M8b — In-app mic (needs a dev build)**
```
M8b: add expo-speech-recognition with hi-IN + en-IN. A big mic button on Home, live transcript
while speaking, auto "Next" when the user stops. If mic permission is denied, fall back to the
keyboard. This won't work in Expo Go: set up an EAS development build (eas.json, app.json plugin
config) and give me the exact commands.
```
- [ ] Installed the EAS build APK on the phone, full flow works with the mic

**M8c — Release APK**
```
M8c: create an EAS preview/release APK profile. EXPO_PUBLIC_API_URL must be the Vercel HTTPS URL.
Check package name in app.json, app name "FlowPay", placeholder icon.
Make sure the PhonePe launch works in the release build too (add Android package visibility
<queries> via a config plugin if needed).
```
- [ ] APK installed, full flow works on mobile data with Wi-Fi off
- [ ] Every item in `docs/TEST-CHECKLIST.md` ticked
