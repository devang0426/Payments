# FlowPay — Architecture

## At a glance

```
┌──────────────────────── PHONE (Android) ───────────────────────────┐
│                                                                     │
│  FlowPay app (Expo)                                                 │
│  ┌───────────────┐   ┌───────────────────┐   ┌──────────────────┐  │
│  │ 1. Input      │   │ 3. Resolver       │   │ 4. Guardrails    │  │
│  │ mic/keyboard  │   │ contacts (expo-   │   │ ₹3,000/payment   │  │
│  │ "Mummy ko 500"│   │ contacts) + seed  │   │ ₹5,000/day       │  │
│  └──────┬────────┘   │ payees.local.json │   │ payee must exist │  │
│         │ text only  │ name→phone→VPA    │   └────────┬─────────┘  │
│         ▼            └─────────▲─────────┘            ▼            │
│   ┌───────────┐                │            ┌──────────────────┐   │
│   │ API call  │── name, ₹ ─────┘            │ 5. Confirm card  │   │
│   └─────┬─────┘                             │ + voice "Send    │   │
│         │                                   │ it?" → "Yes"     │   │
│         │                                   └────────┬─────────┘   │
│         │                                            ▼             │
│         │                                   ┌──────────────────┐   │
│         │                                   │ 6. UPI intent    │   │
│         │                                   │ (intent-launcher)│   │
│         │                                   └────────┬─────────┘   │
│         │                                            ▼             │
│         │                                   ┌──────────────────┐   │
│         │                                   │ PhonePe app      │   │
│         │                                   │ shows real name  │   │
│         │                                   │ → YOU ENTER PIN  │   │
│         │                                   └────────┬─────────┘   │
│         │                                            ▼             │
│         │                                   ┌──────────────────┐   │
│         │                                   │ 7. Result +      │   │
│         │                                   │ receipt + history│   │
│         │                                   └──────────────────┘   │
└─────────┼───────────────────────────────────────────────────────────┘
          │ HTTPS: text only ("Mummy ko 500 bhejo")
          ▼
┌───────────────── SERVER (laptop / Vercel) ──────────┐      ┌────────────┐
│ 2. /parse                                            │─────▶│ OpenRouter │
│ OpenRouter key lives here (not on the phone)         │◀─────│ (AI model) │
│ AI → {name:"Mummy", amountText:"500"}                │      └────────────┘
│ Amount parsed by code → 50000 paise                  │
└──────────────────────────────────────────────────────┘
          │
          ▼  UPI rails → NPCI → banks → money lands in Mom's account
```

## Who does what

| # | Part | Where | Job |
|---|---|---|---|
| 1 | Input | Phone | Speak (keyboard mic first, in-app mic later) or type |
| 2 | Parse (AI) | Server | Extract name and amount from text. Amount converted to paise by code |
| 3 | Resolver | Phone | Name → phone number from contacts → UPI ID from saved payees |
| 4 | Guardrails | Phone | Check limits and stop mistakes |
| 5 | Confirm | Phone | Card + voice, wait for "Yes" |
| 6 | UPI intent | Phone | Open PhonePe directly with everything prefilled |
| 7 | Result | Phone | Receipt and history (for "same as last time") |

## Where data lives (privacy)

| Data | Where | Sent to server or AI? |
|---|---|---|
| Spoken/typed text | Phone → server → AI | Yes, text only |
| Contacts (names, numbers) | Phone only | ❌ Never |
| UPI IDs (saved payees) | Phone only | ❌ Never |
| UPI PIN | Inside PhonePe only | ❌ Our app never sees it |
| Payment history | Phone (local) | ❌ |
| OpenRouter key | Server only | ❌ Not on the phone |

## If something goes wrong

| Situation | What the app does |
|---|---|
| Name matches two contacts | Shows a "Which Mummy?" list |
| Name not found | "No UPI ID saved for Mummy" |
| Amount not understood | "How much do you want to send?" |
| Over ₹3,000, or daily limit reached | Red card + reason; PhonePe does not open |
| Server or internet down | "Couldn't understand that, please try again." Money never moves |
| No result from PhonePe | "Did the payment go through?" [Yes] [No] |

**Design rule:** the AI only understands (name + amount). Deciding and executing happen on the
phone, and money only moves with your PIN. Even if the AI makes a mistake, the confirm card and
the real name shown in PhonePe will catch it.

**Coming later** (same architecture): agent tools on the server (budget, history, scam check),
family alerts on Mom's phone, and a Swiggy MCP. The phone side stays as it is.

## Tech stack

Everything is lightweight: only Node and Git on the laptop, no Android SDK or Java.

| Layer | Choice | Why |
|---|---|---|
| App | Expo (React Native) + TypeScript, Expo Router | One codebase, no Android tooling on the laptop |
| Styling | NativeWind (Tailwind for React Native) | Good UI quickly |
| Contacts | expo-contacts | Look up a number by name |
| Opening the UPI app | expo-intent-launcher | Opens PhonePe directly and returns the result |
| Spoken replies | expo-speech | The phone's built-in TTS, free |
| Mic | Day 1: keyboard (Gboard) mic. Later: expo-speech-recognition | Zero code first, in-app mic later |
| Local storage | expo-secure-store (UPI IDs), AsyncStorage (history) | Sensitive data stays on the phone |
| Validation | Zod | Check the server response and the seed file |
| Server | Node + Express + TypeScript | Only the OpenRouter call; keeps the key off the phone |
| AI | OpenRouter, a fast model with JSON output | Extract name + amount |
| Amount parser | Our own code (handles Hindi number words like "ek", "sau", "paanch sau", "dhai sau", "hazaar") | Don't trust the AI with money |
| Tests | Vitest (server), Jest (app logic) | Amount parser and name matching tests |

## From development to demo

| Stage | How the app runs | Where the server runs |
|---|---|---|
| Development | Expo Go (scan QR on phone) | Laptop (`npm run dev`), same Wi-Fi |
| Adding in-app mic | EAS cloud build → install APK | Laptop or Vercel |
| Demo day | APK (like a normal app) | Vercel (HTTPS) |

By default, an Android release APK won't talk to plain `http://` servers. That's why the demo APK
uses the server on Vercel. During development, Expo Go works fine with the laptop's `http://` server.

## Accounts and tools

| What | Needed? |
|---|---|
| Node + Git (laptop) | ✅ |
| Expo Go app (phone) | ✅ |
| OpenRouter key | ✅ |
| Expo account (for EAS builds) | ✅ when building the APK |
| Vercel | ✅ before the demo |
| PhonePe (on the phone, bank linked) | ✅ |
| Supabase, Railway, Razorpay | ❌ Not now |

See "Repo layout" in `CLAUDE.md` for the folder structure.
