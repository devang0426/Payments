# FlowPay — Phone test checklist (before the demo)

You do all of this **yourself** on the real phone. Every payment is ₹1, to your own UPI ID.

## Setup

- [ ] Release APK installed (not Expo Go)
- [ ] Wi-Fi off, mobile data only (talking to the Vercel server)
- [ ] PhonePe updated, bank linked
- [ ] At least 2 payees in Settings (one of them yourself)

## Happy path

- [ ] Say "Me ko ek rupaya bhejo" with the mic → Confirm card + voice "Send it?"
- [ ] Yes → PhonePe opens with name + ₹1.00 prefilled, and the **real name** in PhonePe is correct
- [ ] Enter PIN → Receipt in the app shows "Done"
- [ ] The entry appears in history
- [ ] "Same as last time" → Confirm for ₹1

## Guardrails

- [ ] "Mummy ko 3001" → red card, PhonePe didn't open
- [ ] "Mummy ko 3000" → normal Confirm (exactly the limit is allowed)
- [ ] Get close to ₹5,000 for the day (test mode / fake history) → next payment blocked
- [ ] Tap "Yes" twice quickly on Confirm → PhonePe opens only once

## Failure cases

- [ ] Two contacts with the same name → "Which Mummy?" list
- [ ] Contact exists but no UPI ID → "No UPI ID saved" + Settings button
- [ ] "Mummy ko bhejo" (no amount) → "How much do you want to send?"
- [ ] "Kya haal hai" (unrelated text) → proper error, nothing proceeds
- [ ] Airplane mode on → "Couldn't understand that, please try again."
- [ ] Press back on the PhonePe PIN screen → "Failed" or "Did the payment go through?"
- [ ] Deny contacts permission → explains why it's needed, no crash
- [ ] Deny mic permission → keyboard fallback

## Privacy check

- [ ] Check the Vercel logs: no phone numbers or UPI IDs
- [ ] `git log -p | grep -i "@ybl\|@okaxis\|@paytm\|@upi"` → only the fake example IDs
- [ ] If you pushed to GitHub, `payees.local.json` and `.env` aren't there

## Demo day

- [ ] Phone charged, notifications silenced
- [ ] A backup screen recording of the full flow (in case the network lets you down)
- [ ] Check Vercel `/health` once in the morning
