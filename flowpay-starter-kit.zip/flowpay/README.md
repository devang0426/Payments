# FlowPay — Getting started

This is a starter kit. There is no code yet; Claude Code will write it milestone by milestone.
The kit contains everything that keeps Claude Code pointed in the right direction.

## What's in the kit

| File | Purpose |
|---|---|
| `CLAUDE.md` | Project rules. Claude Code reads this automatically every session |
| `docs/ARCHITECTURE.md` | The full design |
| `docs/PROMPTS.md` | Copy-paste prompts for M0 to M8, each with a "Done" checklist |
| `docs/PROGRESS.md` | Work log. Claude updates it after every milestone |
| `docs/TEST-CHECKLIST.md` | Things to test yourself on the phone before the demo |
| `.gitignore` | Keeps secrets and real UPI IDs out of git |
| `apps/server/.env.example` | Server environment variables |
| `apps/mobile/.env.example` | The app's server URL |
| `apps/mobile/payees.example.json` | Format for saved payees (fake data) |

## First time only

1. Unzip into a folder named `flowpay`.
2. On your laptop, check `node -v` (an LTS version) and `git --version`.
3. On your phone, install **Expo Go** and **PhonePe** (with a linked bank account).
4. In the folder:
   ```
   cd flowpay
   git init
   git add .
   git commit -m "starter kit"
   ```
5. If Claude Code isn't installed, install it from docs.claude.com.
6. Run `claude` inside the `flowpay` folder.

## The loop for each milestone

1. Copy the next milestone's prompt from `docs/PROMPTS.md`.
2. Turn on **plan mode** in Claude Code (Shift+Tab) and paste the prompt.
3. Read the plan. If anything looks wrong, say so right there. If it looks right, approve it.
4. Claude writes the code and runs the tests. Where something needs checking on the phone, it
   tells you the steps.
5. Tick off the milestone's "Done" list yourself, including the phone checks.
6. `git add . && git commit -m "M1: amount parser"`
7. Run `/clear` and start the next milestone. CLAUDE.md and PROGRESS.md bring the context back.

## Adding secrets (do this yourself, never in chat)

- Copy `apps/server/.env.example` to `apps/server/.env` and add your OpenRouter key.
- Copy `apps/mobile/.env.example` to `apps/mobile/.env` and add your laptop's Wi-Fi IP.
- Copy `apps/mobile/payees.example.json` to `payees.local.json` and add real UPI IDs (after M3).

These files are gitignored. Don't paste their **contents** into the Claude Code chat.

## If you get stuck

- Error on the phone: give Claude the full Metro terminal log and a screenshot.
- Claude is going in circles: "Stop. Explain the cause first, then suggest a different approach."
- Something broke: check `git diff`, or go back to the last commit with `git checkout .`.
